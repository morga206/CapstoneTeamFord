/**
 * Main REST API for MSU Capstone Team Ford's Sentiment Dashboard
 *
 * @since ALPHA
 * @version ALPHA
 */
package sentiment;