package sentiment;

import org.springframework.cloud.function.adapter.aws.SpringBootApiGatewayRequestHandler;

/**
 * Main handler to connect API Gatway -> Lambda -> Spring Cloud Function.
 */
public class Handler extends SpringBootApiGatewayRequestHandler {

}
